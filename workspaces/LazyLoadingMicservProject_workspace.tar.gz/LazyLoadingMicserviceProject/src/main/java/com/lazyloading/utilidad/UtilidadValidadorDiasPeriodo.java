package com.lazyloading.utilidad;

import java.util.Locale;

import com.jcabi.aspects.Loggable;
import com.lazyloading.constante.ConstanteMensajes;
import com.lazyloading.excepcion.ExcepcionObtenerInteger;
import com.lazyloading.excepcion.ExcepcionVerificarArrayDiasElementos;
import com.lazyloading.excepcion.ExcepcionVerificarContadorArrDiasElementos;
import com.lazyloading.excepcion.ExcepcionVerificarDiasElementos;
import com.lazyloading.excepcion.ExcepcionVerificarVecesDos;
import com.lazyloading.excepcion.ExcepcionVerificarVecesUno;
import com.lazyloading.factoria.FactoriaLocale;
import com.lazyloading.mensaje.UtilidadMensajes;

public final class UtilidadValidadorDiasPeriodo {
	
	@Loggable
	public static int obtenerInteger(String strValor) throws ExcepcionObtenerInteger {
		int valor = 0;
		try {
			valor = Integer.parseInt(strValor);
		} catch(NumberFormatException nfe) {
			Locale locale = FactoriaLocale.getFactoriaLocale().getLocale();
			String key = ConstanteMensajes.OBTENER_INTEGER.getKey();
			String mensajeError = UtilidadMensajes.buscarMensaje(key, locale);
			throw new ExcepcionObtenerInteger(mensajeError, nfe);
		}
		return valor;
	}
	
	@Loggable
	public static void verificarDiasElementos(String diasElementos) throws ExcepcionVerificarDiasElementos {
		if(diasElementos == null
				|| diasElementos.isEmpty()) {
			Locale locale = FactoriaLocale.getFactoriaLocale().getLocale();
			String key = ConstanteMensajes.VERIFICAR_DIAS_ELEMENTOS.getKey();
			String mensajeError = UtilidadMensajes.buscarMensaje(key, locale);
			throw new ExcepcionVerificarDiasElementos(mensajeError);
		}
	}
	
	@Loggable
	public static void verificarArrayDiasElementos(String[] arrayDiasElementos) throws ExcepcionVerificarArrayDiasElementos {
		if(arrayDiasElementos == null
				|| arrayDiasElementos.length == 0) {
			Locale locale = FactoriaLocale.getFactoriaLocale().getLocale();
			String key = ConstanteMensajes.VERIFICAR_ARRAY_DIAS_ELEMENTOS.getKey();
			String mensajeError = UtilidadMensajes.buscarMensaje(key, locale);
			throw new ExcepcionVerificarArrayDiasElementos(mensajeError);
		}
	}
	
	@Loggable
	public static void verificarCantidadDiasPeriodo(String cantidadDiasPeriodo) throws ExcepcionVerificarVecesUno {
		if(cantidadDiasPeriodo == null
				|| cantidadDiasPeriodo.isEmpty()) {
			Locale locale = FactoriaLocale.getFactoriaLocale().getLocale();
			String key = ConstanteMensajes.VERIFICAR_VECES_UNO.getKey();
			String mensajeError = UtilidadMensajes.buscarMensaje(key, locale);
			throw new ExcepcionVerificarVecesUno(mensajeError);
		}
	}
	
	@Loggable
	public static void verificarCantidadDiasPeriodo(int cantidadDiasPeriodo, String[] arrayDiasElementos) throws ExcepcionVerificarVecesDos {
		if(cantidadDiasPeriodo > arrayDiasElementos.length) {
			Locale locale = FactoriaLocale.getFactoriaLocale().getLocale();
			String key = ConstanteMensajes.VERIFICAR_VECES_DOS.getKey();
			String mensajeError = UtilidadMensajes.buscarMensaje(key, locale);
			throw new ExcepcionVerificarVecesDos(mensajeError);
		}
	}
	
	@Loggable
	public static void verificarContadorArrDiasElementos(int contadorArrDiasElementos, String[] arrayDiasElementos) 
			throws ExcepcionVerificarContadorArrDiasElementos {
		if(contadorArrDiasElementos >= arrayDiasElementos.length) {
			Locale locale = FactoriaLocale.getFactoriaLocale().getLocale();
			String key = ConstanteMensajes.VERIFICAR_CONTADOR_ARR_DIAS_ELEMENTOS.getKey();
			String mensajeError = UtilidadMensajes.buscarMensaje(key, locale);
			throw new ExcepcionVerificarContadorArrDiasElementos(mensajeError);
		}
	}
	
}
