package com.lazyloading;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LazyLoadingMicserviceProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LazyLoadingMicserviceProjectApplication.class, args);
	}
}
