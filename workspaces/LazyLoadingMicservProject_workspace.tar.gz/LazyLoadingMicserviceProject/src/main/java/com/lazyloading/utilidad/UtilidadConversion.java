package com.lazyloading.utilidad;

import java.util.Collection;
import java.util.Locale;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.jcabi.aspects.Loggable;
import com.lazyloading.constante.ConstanteMensajes;
import com.lazyloading.excepcion.ExcepcionConvertirListaJSON;
import com.lazyloading.factoria.FactoriaLocale;
import com.lazyloading.mensaje.UtilidadMensajes;

public final class UtilidadConversion {

	private UtilidadConversion() {
		super();
	}

	@Loggable
	public static String convertirListaJSON(Collection<?> listaElementos) 
		throws ExcepcionConvertirListaJSON {
		if(listaElementos == null) {
			ConstanteMensajes constanteMensajes = ConstanteMensajes.LISTA_JSON_NULL;
			arrojarExcepcionConvertirListaJSON(constanteMensajes);
		}
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.create();
		String listaLineaImpresionJSON = gson.toJson(listaElementos);
		return listaLineaImpresionJSON;
	}
	
	@Loggable
	public static String convertirListaJSON(
			Collection<?> listaElementos, Class<?> claseElemento, TypeAdapter<?> adaptadorJSON) 
		throws ExcepcionConvertirListaJSON {
		if(listaElementos == null) {
			ConstanteMensajes constanteMensajes = ConstanteMensajes.LISTA_JSON_NULL;
			arrojarExcepcionConvertirListaJSON(constanteMensajes);
		} else if(claseElemento == null) {
			ConstanteMensajes constanteMensajes = ConstanteMensajes.CLASE_ELEMENTO_JSON_NULL;
			arrojarExcepcionConvertirListaJSON(constanteMensajes);
		} else if(adaptadorJSON == null) {
			ConstanteMensajes constanteMensajes = ConstanteMensajes.ADAPTADOR_JSON_NULL;
			arrojarExcepcionConvertirListaJSON(constanteMensajes);
		}
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(claseElemento, adaptadorJSON);
		Gson gson = gsonBuilder.create();
		String listaLineaImpresionJSON = gson.toJson(listaElementos);
		return listaLineaImpresionJSON;
	}

	private static String obtenerMensaje(ConstanteMensajes constanteMensajes) {
		Locale locale = FactoriaLocale.getFactoriaLocale().getLocale();
		String key = constanteMensajes.getKey();
		String mensajeError = UtilidadMensajes.buscarMensaje(key, locale);
		return mensajeError;
	}
	
	private static void arrojarExcepcionConvertirListaJSON(ConstanteMensajes constanteMensajes) {
		String mensajeError = obtenerMensaje(constanteMensajes);
		throw new ExcepcionConvertirListaJSON(mensajeError);
	}

}
