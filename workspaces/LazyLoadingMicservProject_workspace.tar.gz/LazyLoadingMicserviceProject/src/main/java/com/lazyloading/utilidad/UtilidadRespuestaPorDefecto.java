package com.lazyloading.utilidad;

import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

import com.jcabi.aspects.Loggable;
import com.lazyloading.constante.ConstanteMensajes;
import com.lazyloading.factoria.FactoriaLocale;
import com.lazyloading.mensaje.UtilidadMensajes;
import com.lazyloading.modelo.LineaImpresion;

public final class UtilidadRespuestaPorDefecto {

	private UtilidadRespuestaPorDefecto() {
		super();
	}

	@Loggable
	public static Set<LineaImpresion> obtenerLineaImpresion() {
		Locale locale = FactoriaLocale.getFactoriaLocale().getLocale();
		String key = ConstanteMensajes.OBTENER_LINEA_IMPRESION.getKey();
		String mensajeError = UtilidadMensajes.buscarMensaje(key, locale);
		LineaImpresion lineaImpresion = 
				new LineaImpresion();
		lineaImpresion.setCodigo(-1);
		lineaImpresion.setDescripcionLinea(mensajeError);
		Set<LineaImpresion> listaLineaImpresion = new TreeSet<>();
		listaLineaImpresion.add(lineaImpresion);
		return listaLineaImpresion;
	}
	
}
