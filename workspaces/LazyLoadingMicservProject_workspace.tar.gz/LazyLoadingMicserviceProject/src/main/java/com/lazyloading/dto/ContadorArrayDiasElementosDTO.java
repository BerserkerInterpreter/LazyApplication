package com.lazyloading.dto;

public class ContadorArrayDiasElementosDTO {

	private Integer contadorArrayDiasElementos;
	
	public ContadorArrayDiasElementosDTO() {
		super();
	}

	public ContadorArrayDiasElementosDTO(Integer contadorArrayDiasElementos) {
		this.contadorArrayDiasElementos = contadorArrayDiasElementos;
	}

	public Integer getContadorArrayDiasElementos() {
		return contadorArrayDiasElementos;
	}

	public void setContadorArrayDiasElementos(Integer contadorArrayDiasElementos) {
		this.contadorArrayDiasElementos = contadorArrayDiasElementos;
	}

}
