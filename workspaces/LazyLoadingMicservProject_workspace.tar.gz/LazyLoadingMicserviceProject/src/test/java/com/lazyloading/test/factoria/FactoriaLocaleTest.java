package com.lazyloading.test.factoria;

import java.util.Locale;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.lazyloading.factoria.FactoriaLocale;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FactoriaLocaleTest {

	@Test
	public void testGetFactoriaLocale() {
		FactoriaLocale factoriaLocale = 
				FactoriaLocale.getFactoriaLocale();
		Assert.assertNotNull("TEST: La variable factoriaLocale es igual a null.", factoriaLocale);
	}
	
	@Test
	public void testGetLocale() {
		FactoriaLocale factoriaLocale = 
				FactoriaLocale.getFactoriaLocale();
		Locale locale = factoriaLocale.getLocale();
		Assert.assertNotNull("TEST: La variable locale es igual a null.", locale);
		String lenguaje = locale.getLanguage();
		String pais = locale.getCountry();
		Assert.assertNotNull("TEST: El lenguaje del locale es igual a null.", lenguaje);
		Assert.assertNotEquals("TEST: El lenguaje del locale esta vacio.", "", lenguaje);
		Assert.assertNotNull("TEST: El pais del locale es igual a null.", pais);
		Assert.assertNotEquals("TEST: El pais del locale esta vacio.", "", pais);
	}

}
